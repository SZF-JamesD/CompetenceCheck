from enum import Enum

class Intervals(Enum):
    P1 = 0
    A1 = 1
    m2 = 1
    M2 = 2
    A2 = 3
    m3 =3
    M3 = 4
    P4 = 5
    TT = 6
    d5 = 6
    P5 = 7
    A5 = 8
    m6 = 8
    M6 = 9
    A6 = 10
    m7 = 10
    M7 = 11
    PO = 12
    M9 = 14