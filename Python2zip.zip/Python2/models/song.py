from models.chord import Chord

class Song:
    def __init__(self, title):
        self.title = title
        self.chords = []

    